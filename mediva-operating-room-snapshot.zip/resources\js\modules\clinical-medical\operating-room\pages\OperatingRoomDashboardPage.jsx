import React, { useEffect, useState } from "react";

import { Link } from "react-router-dom";

import DashboardLayout from "../../../../shared/components/layout/DashboardLayout";

import { operatingRoomService } from "../services/operatingRoomService";

import SurgeryStatusBadge from "../components/SurgeryStatusBadge";

import { dateTime } from "../utils/operatingRoom";

/*
|--------------------------------------------------------------------------
| OPERATING ROOM DASHBOARD
|--------------------------------------------------------------------------
*/

export default function OperatingRoomDashboardPage() {
    const [data, setData] = useState(null);

    const [loading, setLoading] = useState(true);

    const [error, setError] = useState("");

    /*
    |--------------------------------------------------------------------------
    | LOAD DASHBOARD
    |--------------------------------------------------------------------------
    */

    useEffect(() => {
        const loadDashboard = async () => {
            try {
                setLoading(true);

                setError("");

                const response = await operatingRoomService.getDashboard();

                /*
                |--------------------------------------------------------------------------
                | API MEDIVA
                |--------------------------------------------------------------------------
                |
                | api.js sudah return JSON langsung.
                |
                | Backend:
                |
                | {
                |     data: {
                |         today_total: 0,
                |         ...
                |     }
                | }
                |
                */

                setData(response?.data ?? response);
            } catch (err) {
                console.error("Operating Room Dashboard Error:", err);

                setError(
                    err?.data?.message ??
                        err?.message ??
                        "Gagal memuat dashboard kamar operasi.",
                );
            } finally {
                setLoading(false);
            }
        };

        loadDashboard();
    }, []);

    /*
    |--------------------------------------------------------------------------
    | LOADING
    |--------------------------------------------------------------------------
    */

    if (loading) {
        return (
            <DashboardLayout>
                <div
                    className="
                        min-h-[calc(100vh-88px)]
                        bg-[#fafbfc]
                        p-[30px]
                    "
                >
                    <div
                        className="
                            rounded-[14px]
                            border
                            border-[#eeeeee]
                            bg-white
                            p-[20px]
                            text-[13px]
                            text-[#888888]
                        "
                    >
                        Memuat dashboard kamar operasi...
                    </div>
                </div>
            </DashboardLayout>
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ERROR
    |--------------------------------------------------------------------------
    */

    if (error) {
        return (
            <DashboardLayout>
                <div
                    className="
                        min-h-[calc(100vh-88px)]
                        bg-[#fafbfc]
                        p-[30px]
                    "
                >
                    <div
                        className="
                            rounded-[14px]
                            border
                            border-red-100
                            bg-red-50
                            p-[20px]
                            text-[13px]
                            text-red-600
                        "
                    >
                        {error}
                    </div>
                </div>
            </DashboardLayout>
        );
    }

    /*
    |--------------------------------------------------------------------------
    | DATA
    |--------------------------------------------------------------------------
    */

    const dashboard = data ?? {};

    const cards = [
        {
            label: "Operasi Hari Ini",
            value: dashboard.today_total ?? 0,
        },
        {
            label: "Menunggu",
            value: dashboard.waiting ?? 0,
        },
        {
            label: "Sedang Operasi",
            value: dashboard.in_progress ?? 0,
        },
        {
            label: "Pemulihan",
            value: dashboard.recovery ?? 0,
        },
        {
            label: "Selesai Hari Ini",
            value: dashboard.completed_today ?? 0,
        },
        {
            label: "Kamar Tersedia",
            value: dashboard.rooms_available ?? 0,
        },
    ];

    const todaySchedule = dashboard.today_schedule ?? [];

    /*
    |--------------------------------------------------------------------------
    | RENDER
    |--------------------------------------------------------------------------
    */

    return (
        <DashboardLayout>
            <div
                className="
                    min-h-[calc(100vh-88px)]
                    bg-[#fafbfc]
                    p-[30px]
                "
            >
                {/*
                |--------------------------------------------------------------------------
                | HEADER
                |--------------------------------------------------------------------------
                */}

                <div
                    className="
                        flex
                        flex-wrap
                        items-center
                        justify-between
                        gap-[15px]
                    "
                >
                    <div>
                        <h1
                            className="
                                text-[24px]
                                font-semibold
                                text-[#343434]
                            "
                        >
                            Kamar Operasi
                        </h1>

                        <p
                            className="
                                mt-[5px]
                                text-[12px]
                                text-[#999999]
                            "
                        >
                            Kelola jadwal, tindakan, keselamatan operasi, dan
                            pemulihan pasien.
                        </p>
                    </div>

                    <div
                        className="
                            flex
                            flex-wrap
                            gap-[9px]
                        "
                    >
                        <Link
                            to="/clinical/operating-room/master"
                            className="
                                rounded-[9px]
                                border
                                border-[#dddddd]
                                bg-white
                                px-[14px]
                                py-[9px]
                                text-[12px]
                                font-medium
                                text-[#555555]
                                transition
                                hover:bg-[#f7f9fb]
                            "
                        >
                            Master Kamar Operasi
                        </Link>

                        <Link
                            to="/clinical/operating-room/surgeries"
                            className="
                                rounded-[9px]
                                border
                                border-[#dddddd]
                                bg-white
                                px-[14px]
                                py-[9px]
                                text-[12px]
                                font-medium
                                text-[#555555]
                                transition
                                hover:bg-[#f7f9fb]
                            "
                        >
                            Daftar Operasi
                        </Link>

                        <Link
                            to="/clinical/operating-room/surgeries/new"
                            className="
                                rounded-[9px]
                                bg-[#1688f8]
                                px-[14px]
                                py-[9px]
                                text-[12px]
                                font-medium
                                text-white
                                transition
                                hover:bg-[#0878e5]
                            "
                        >
                            + Permintaan Operasi
                        </Link>
                    </div>
                </div>

                {/*
                |--------------------------------------------------------------------------
                | STATISTICS
                |--------------------------------------------------------------------------
                */}

                <div
                    className="
                        mt-[24px]
                        grid
                        grid-cols-1
                        gap-[14px]
                        sm:grid-cols-2
                        xl:grid-cols-3
                    "
                >
                    {cards.map((card) => (
                        <div
                            key={card.label}
                            className="
                                rounded-[14px]
                                border
                                border-[#ececec]
                                bg-white
                                p-[18px]
                            "
                        >
                            <p
                                className="
                                    text-[11px]
                                    font-medium
                                    text-[#999999]
                                "
                            >
                                {card.label}
                            </p>

                            <p
                                className="
                                    mt-[8px]
                                    text-[26px]
                                    font-semibold
                                    text-[#343434]
                                "
                            >
                                {card.value}
                            </p>
                        </div>
                    ))}
                </div>

                {/*
                |--------------------------------------------------------------------------
                | TODAY SCHEDULE
                |--------------------------------------------------------------------------
                */}

                <section
                    className="
                        mt-[20px]
                        overflow-hidden
                        rounded-[14px]
                        border
                        border-[#ececec]
                        bg-white
                    "
                >
                    <div
                        className="
                            flex
                            items-center
                            justify-between
                            border-b
                            border-[#eeeeee]
                            px-[20px]
                            py-[17px]
                        "
                    >
                        <div>
                            <h2
                                className="
                                    text-[15px]
                                    font-semibold
                                    text-[#343434]
                                "
                            >
                                Jadwal Operasi Hari Ini
                            </h2>

                            <p
                                className="
                                    mt-[3px]
                                    text-[11px]
                                    text-[#999999]
                                "
                            >
                                Daftar operasi yang dijadwalkan hari ini.
                            </p>
                        </div>

                        <Link
                            to="/clinical/operating-room/surgeries"
                            className="
                                text-[12px]
                                font-medium
                                text-[#1688f8]
                            "
                        >
                            Lihat Semua
                        </Link>
                    </div>

                    <div className="overflow-x-auto">
                        <table
                            className="
                                w-full
                                min-w-[760px]
                                text-left
                            "
                        >
                            <thead
                                className="
                                    bg-[#fafafa]
                                    text-[11px]
                                    text-[#777777]
                                "
                            >
                                <tr>
                                    <th className="px-[18px] py-[13px]">
                                        Nomor
                                    </th>

                                    <th className="px-[18px] py-[13px]">
                                        Pasien
                                    </th>

                                    <th className="px-[18px] py-[13px]">
                                        Jenis Operasi
                                    </th>

                                    <th className="px-[18px] py-[13px]">
                                        Kamar
                                    </th>

                                    <th className="px-[18px] py-[13px]">
                                        Jadwal
                                    </th>

                                    <th className="px-[18px] py-[13px]">
                                        Status
                                    </th>
                                </tr>
                            </thead>

                            <tbody>
                                {todaySchedule.length === 0 ? (
                                    <tr>
                                        <td
                                            colSpan="6"
                                            className="
                                                px-[18px]
                                                py-[35px]
                                                text-center
                                                text-[12px]
                                                text-[#aaaaaa]
                                            "
                                        >
                                            Belum ada jadwal operasi hari ini.
                                        </td>
                                    </tr>
                                ) : (
                                    todaySchedule.map((item) => (
                                        <tr
                                            key={item.id}
                                            className="
                                                    border-t
                                                    border-[#eeeeee]
                                                "
                                        >
                                            <td
                                                className="
                                                        px-[18px]
                                                        py-[14px]
                                                        text-[12px]
                                                        font-medium
                                                        text-[#444444]
                                                    "
                                            >
                                                <Link
                                                    to={`/clinical/operating-room/surgeries/${item.id}`}
                                                    className="
                                                            text-[#1688f8]
                                                        "
                                                >
                                                    {item.surgery_number ?? "-"}
                                                </Link>
                                            </td>

                                            <td className="px-[18px] py-[14px] text-[12px] text-[#555555]">
                                                {item.patient?.name ?? "-"}
                                            </td>

                                            <td className="px-[18px] py-[14px] text-[12px] text-[#555555]">
                                                {item.operation_type?.name ??
                                                    "-"}
                                            </td>

                                            <td className="px-[18px] py-[14px] text-[12px] text-[#555555]">
                                                {item.operating_room?.name ??
                                                    "-"}
                                            </td>

                                            <td className="px-[18px] py-[14px] text-[12px] text-[#555555]">
                                                {dateTime(
                                                    item.scheduled_start_at,
                                                )}
                                            </td>

                                            <td className="px-[18px] py-[14px]">
                                                <SurgeryStatusBadge
                                                    status={item.status}
                                                />
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </DashboardLayout>
    );
}
