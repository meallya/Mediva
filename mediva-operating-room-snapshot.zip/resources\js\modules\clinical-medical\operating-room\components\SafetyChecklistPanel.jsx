import React, { useEffect, useMemo, useState } from "react";

const template = {
    preoperative: [
        ["identity", "Identitas pasien sesuai"],
        ["procedure", "Tindakan operasi sesuai"],
        ["consent", "Persetujuan tindakan tersedia"],
        ["fasting", "Status puasa terkonfirmasi"],
        ["supporting", "Pemeriksaan penunjang tersedia"],
        ["preparation", "Persiapan pasien lengkap"],
    ],
    "sign-in": [
        ["identity", "Konfirmasi identitas pasien"],
        ["site", "Konfirmasi lokasi operasi"],
        ["procedure", "Konfirmasi prosedur"],
        ["consent", "Konfirmasi informed consent"],
        ["anesthesia", "Pemeriksaan keamanan anestesi"],
        ["allergy", "Alergi diketahui / dikonfirmasi"],
    ],
    "time-out": [
        ["team", "Seluruh anggota tim memperkenalkan diri"],
        ["patient", "Konfirmasi pasien, lokasi, dan prosedur"],
        ["critical", "Antisipasi kejadian kritis dibahas"],
        ["antibiotic", "Profilaksis antibiotik dikonfirmasi bila perlu"],
        ["imaging", "Imaging penting tersedia bila diperlukan"],
    ],
    "sign-out": [
        ["procedure", "Nama prosedur yang dilakukan dikonfirmasi"],
        ["count", "Hitung instrumen, kasa, dan jarum lengkap"],
        ["specimen", "Spesimen diberi label dengan benar bila ada"],
        ["equipment", "Masalah alat dicatat bila ada"],
        ["recovery", "Rencana pemulihan dan pasca operasi dibahas"],
    ],
};

export default function SafetyChecklistPanel({
    phase,
    initialItems = [],
    onSave,
    disabled = false,
}) {
    const seed = useMemo(() => {
        if (initialItems?.length) {
            return initialItems;
        }

        return (template[phase] || []).map(([key, label]) => ({
            key,
            label,
            checked: false,
            note: "",
        }));
    }, [phase, initialItems]);

    const [items, setItems] = useState(seed);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        setItems(seed);
    }, [seed]);

    const toggle = (index) => {
        setItems((prev) =>
            prev.map((item, itemIndex) =>
                itemIndex === index
                    ? {
                          ...item,
                          checked: !item.checked,
                      }
                    : item,
            ),
        );
    };

    const save = async () => {
        setSaving(true);

        try {
            await onSave(items);
        } finally {
            setSaving(false);
        }
    };

    return (
        <section className="rounded-[14px] border border-[#ececec] bg-white p-[18px]">
            <div className="space-y-[8px]">
                {items.map((item, index) => (
                    <label
                        key={item.key}
                        className="flex cursor-pointer items-start gap-[10px] rounded-[9px] border border-[#eeeeee] px-[12px] py-[10px] transition hover:bg-[#fafcff]"
                    >
                        <input
                            type="checkbox"
                            checked={Boolean(item.checked)}
                            disabled={disabled}
                            onChange={() => toggle(index)}
                            className="mt-[2px] h-[16px] w-[16px] accent-[#1688f8]"
                        />
                        <span className="text-[12px] font-medium text-[#555555]">
                            {item.label}
                        </span>
                    </label>
                ))}
            </div>

            {!disabled && (
                <button
                    type="button"
                    onClick={save}
                    disabled={saving || items.some((item) => !item.checked)}
                    className="mt-[14px] inline-flex h-[40px] items-center rounded-[9px] bg-[#1688f8] px-[15px] text-[11px] font-medium text-white transition hover:bg-[#0f7be8] disabled:cursor-not-allowed disabled:opacity-50"
                >
                    {saving ? "Menyimpan..." : "Simpan Checklist"}
                </button>
            )}
        </section>
    );
}
