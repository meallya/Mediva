import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import DashboardLayout from "../../../../shared/components/layout/DashboardLayout";

import { operatingRoomService } from "../services/operatingRoomService";

const initialForm = {
    patient_id: "",
    visit_id: "",
    requesting_doctor_id: "",
    operator_doctor_id: "",
    anesthesiologist_doctor_id: "",
    operation_type_id: "",
    priority: "elective",
    preoperative_diagnosis: "",
    planned_procedure: "",
    consent_obtained: false,
    fasting_status: "not_started",
    supporting_examinations: "",
    patient_preparation: "",
};

export default function SurgeryFormPage() {
    const navigate = useNavigate();

    const [form, setForm] = useState(initialForm);
    const [options, setOptions] = useState({
        operation_types: [],
        priorities: [],
    });
    const [loadingOptions, setLoadingOptions] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState("");

    useEffect(() => {
        const loadOptions = async () => {
            try {
                setLoadingOptions(true);

                const response = await operatingRoomService.getOptions();
                setOptions(response?.data ?? {});
            } catch (err) {
                setError(
                    err?.data?.message ??
                        err?.message ??
                        "Gagal memuat pilihan operasi.",
                );
            } finally {
                setLoadingOptions(false);
            }
        };

        loadOptions();
    }, []);

    const change = (event) => {
        const { name, value, type, checked } = event.target;

        setForm((prev) => ({
            ...prev,
            [name]: type === "checkbox" ? checked : value,
        }));
    };

    const submit = async (event) => {
        event.preventDefault();

        try {
            setSaving(true);
            setError("");

            const payload = Object.fromEntries(
                Object.entries(form).map(([key, value]) => [
                    key,
                    key.endsWith("_id") && value !== ""
                        ? Number(value)
                        : value,
                ]),
            );

            const response = await operatingRoomService.createSurgery(payload);
            const surgery = response?.data ?? null;

            if (surgery?.id) {
                navigate(`/clinical/operating-room/surgeries/${surgery.id}`);
                return;
            }

            navigate("/clinical/operating-room/surgeries");
        } catch (err) {
            setError(
                err?.data?.message ??
                    err?.message ??
                    "Permintaan operasi gagal disimpan.",
            );
        } finally {
            setSaving(false);
        }
    };

    return (
        <DashboardLayout>
            <div className="min-h-[calc(100vh-88px)] bg-[#fafbfc] p-[30px]">
                <div className="flex flex-wrap items-center justify-between gap-[12px]">
                    <div>
                        <h1 className="text-[24px] font-semibold text-[#343434]">
                            Permintaan Operasi
                        </h1>
                        <p className="mt-[5px] text-[12px] text-[#999999]">
                            Buat permintaan operasi berdasarkan pasien dan kunjungan aktif.
                        </p>
                    </div>

                    <Link
                        to="/clinical/operating-room/surgeries"
                        className="inline-flex h-[40px] items-center rounded-[9px] border border-[#dddddd] bg-white px-[14px] text-[11px] font-medium text-[#666666] transition hover:bg-[#f7f9fb]"
                    >
                        Kembali ke Daftar Operasi
                    </Link>
                </div>

                {error && (
                    <div className="mt-[18px] rounded-[10px] border border-red-100 bg-red-50 px-[14px] py-[11px] text-[12px] text-red-600">
                        {error}
                    </div>
                )}

                <form onSubmit={submit} className="mt-[22px]">
                    <section className="rounded-[14px] border border-[#ececec] bg-white p-[20px]">
                        <SectionTitle
                            title="Informasi Permintaan"
                            subtitle="Lengkapi data pasien, kunjungan, dan rencana operasi."
                        />

                        <div className="mt-[18px] grid grid-cols-1 gap-[16px] md:grid-cols-2">
                            <Field label="ID Pasien" required>
                                <input
                                    name="patient_id"
                                    type="number"
                                    min="1"
                                    value={form.patient_id}
                                    onChange={change}
                                    required
                                    placeholder="Masukkan ID pasien"
                                    className={inputClass}
                                />
                            </Field>

                            <Field label="ID Kunjungan" required>
                                <input
                                    name="visit_id"
                                    type="number"
                                    min="1"
                                    value={form.visit_id}
                                    onChange={change}
                                    required
                                    placeholder="Masukkan ID kunjungan"
                                    className={inputClass}
                                />
                            </Field>

                            <Field label="ID Dokter Peminta">
                                <input
                                    name="requesting_doctor_id"
                                    type="number"
                                    min="1"
                                    value={form.requesting_doctor_id}
                                    onChange={change}
                                    placeholder="Opsional"
                                    className={inputClass}
                                />
                            </Field>

                            <Field label="Jenis Operasi">
                                <select
                                    name="operation_type_id"
                                    value={form.operation_type_id}
                                    onChange={change}
                                    disabled={loadingOptions}
                                    className={inputClass}
                                >
                                    <option value="">
                                        {loadingOptions
                                            ? "Memuat jenis operasi..."
                                            : "Pilih Jenis Operasi"}
                                    </option>
                                    {options.operation_types?.map((item) => (
                                        <option key={item.id} value={item.id}>
                                            {item.name}
                                        </option>
                                    ))}
                                </select>
                            </Field>

                            <Field label="Prioritas" required>
                                <select
                                    name="priority"
                                    value={form.priority}
                                    onChange={change}
                                    className={inputClass}
                                >
                                    {(options.priorities?.length
                                        ? options.priorities
                                        : [
                                              {
                                                  value: "elective",
                                                  label: "Elektif",
                                              },
                                              {
                                                  value: "urgent",
                                                  label: "Urgent",
                                              },
                                              {
                                                  value: "emergency",
                                                  label: "Emergensi",
                                              },
                                          ]
                                    ).map((item) => (
                                        <option key={item.value} value={item.value}>
                                            {item.label}
                                        </option>
                                    ))}
                                </select>
                            </Field>

                            <Field label="Status Puasa">
                                <select
                                    name="fasting_status"
                                    value={form.fasting_status}
                                    onChange={change}
                                    className={inputClass}
                                >
                                    <option value="not_required">
                                        Tidak Diperlukan
                                    </option>
                                    <option value="not_started">Belum Mulai</option>
                                    <option value="in_progress">Sedang Puasa</option>
                                    <option value="adequate">Adekuat</option>
                                    <option value="not_adequate">
                                        Belum Adekuat
                                    </option>
                                </select>
                            </Field>
                        </div>
                    </section>

                    <section className="mt-[18px] rounded-[14px] border border-[#ececec] bg-white p-[20px]">
                        <SectionTitle
                            title="Informasi Klinis Pra Operasi"
                            subtitle="Catat diagnosis, rencana tindakan, pemeriksaan penunjang, dan persiapan pasien."
                        />

                        <div className="mt-[18px] space-y-[16px]">
                            <TextArea
                                label="Diagnosis Pra Operasi"
                                name="preoperative_diagnosis"
                                value={form.preoperative_diagnosis}
                                onChange={change}
                                placeholder="Masukkan diagnosis pra operasi"
                            />

                            <TextArea
                                label="Rencana Tindakan"
                                name="planned_procedure"
                                value={form.planned_procedure}
                                onChange={change}
                                placeholder="Masukkan rencana tindakan operasi"
                            />

                            <TextArea
                                label="Pemeriksaan Penunjang"
                                name="supporting_examinations"
                                value={form.supporting_examinations}
                                onChange={change}
                                placeholder="Laboratorium, radiologi, atau pemeriksaan lain yang relevan"
                                rows={4}
                            />

                            <TextArea
                                label="Persiapan Pasien"
                                name="patient_preparation"
                                value={form.patient_preparation}
                                onChange={change}
                                placeholder="Catat persiapan pasien sebelum operasi"
                                rows={4}
                            />

                            <label className="flex cursor-pointer items-start gap-[10px] rounded-[10px] border border-[#eeeeee] bg-[#fafafa] px-[13px] py-[12px]">
                                <input
                                    type="checkbox"
                                    name="consent_obtained"
                                    checked={form.consent_obtained}
                                    onChange={change}
                                    className="mt-[2px] h-[16px] w-[16px] accent-[#1688f8]"
                                />
                                <div>
                                    <p className="text-[12px] font-medium text-[#444444]">
                                        Persetujuan tindakan sudah diperoleh
                                    </p>
                                    <p className="mt-[2px] text-[10px] text-[#999999]">
                                        Tandai jika informed consent telah dikonfirmasi.
                                    </p>
                                </div>
                            </label>
                        </div>
                    </section>

                    <div className="mt-[18px] flex justify-end">
                        <button
                            type="submit"
                            disabled={saving}
                            className="inline-flex h-[42px] min-w-[190px] items-center justify-center rounded-[9px] bg-[#1688f8] px-[18px] text-[12px] font-medium text-white transition hover:bg-[#0f7be8] disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            {saving
                                ? "Menyimpan..."
                                : "Simpan Permintaan Operasi"}
                        </button>
                    </div>
                </form>
            </div>
        </DashboardLayout>
    );
}

const inputClass = `
    h-[42px]
    w-full
    rounded-[9px]
    border
    border-[#dddddd]
    bg-white
    px-[12px]
    text-[13px]
    text-[#444444]
    outline-none
    transition
    placeholder:text-[#bbbbbb]
    focus:border-[#1688f8]
    disabled:cursor-not-allowed
    disabled:bg-[#f7f7f7]
`;

function SectionTitle({ title, subtitle }) {
    return (
        <div>
            <h2 className="text-[15px] font-semibold text-[#343434]">{title}</h2>
            <p className="mt-[2px] text-[11px] text-[#999999]">{subtitle}</p>
        </div>
    );
}

function Field({ label, required = false, children }) {
    return (
        <div>
            <label className="mb-[6px] block text-[12px] font-medium text-[#555555]">
                {label}
                {required && <span className="ml-[3px] text-red-400">*</span>}
            </label>
            {children}
        </div>
    );
}

function TextArea({ label, rows = 5, ...props }) {
    return (
        <div>
            <label className="mb-[6px] block text-[12px] font-medium text-[#555555]">
                {label}
            </label>
            <textarea
                {...props}
                rows={rows}
                className="w-full resize-y rounded-[9px] border border-[#dddddd] bg-white px-[12px] py-[10px] text-[13px] leading-[1.6] text-[#444444] outline-none transition placeholder:text-[#bbbbbb] focus:border-[#1688f8]"
            />
        </div>
    );
}
