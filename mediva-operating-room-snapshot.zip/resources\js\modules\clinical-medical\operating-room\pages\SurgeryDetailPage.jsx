import React, { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";

import DashboardLayout from "../../../../shared/components/layout/DashboardLayout";

import SafetyChecklistPanel from "../components/SafetyChecklistPanel";
import SurgeryStatusBadge from "../components/SurgeryStatusBadge";
import UsageForm from "../components/UsageForm";
import { operatingRoomService } from "../services/operatingRoomService";
import { dateTime, priorityLabel } from "../utils/operatingRoom";

export default function SurgeryDetailPage() {
    const { id } = useParams();

    const [surgery, setSurgery] = useState(null);
    const [tab, setTab] = useState("ringkasan");
    const [loading, setLoading] = useState(true);
    const [actionLoading, setActionLoading] = useState(false);
    const [error, setError] = useState("");

    const load = async () => {
        try {
            setLoading(true);
            setError("");

            const response = await operatingRoomService.getSurgery(id);
            setSurgery(response?.data ?? null);
        } catch (err) {
            setError(
                err?.data?.message ??
                    err?.message ??
                    "Gagal memuat detail operasi.",
            );
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        load();
    }, [id]);

    const checklist = surgery?.safety_checklist || {};

    const actions = useMemo(() => {
        if (!surgery) {
            return [];
        }

        return [
            surgery.status !== "in_progress" &&
            !["completed", "cancelled", "recovery"].includes(surgery.status)
                ? ["Mulai Operasi", () => operatingRoomService.startSurgery(id)]
                : null,
            surgery.status === "in_progress"
                ? [
                      "Selesai Operasi",
                      () => operatingRoomService.finishSurgery(id),
                  ]
                : null,
            surgery.status === "recovery"
                ? [
                      "Tutup Episode Operasi",
                      () => operatingRoomService.completeSurgery(id),
                  ]
                : null,
        ].filter(Boolean);
    }, [surgery, id]);

    const runAction = async (fn) => {
        try {
            setActionLoading(true);
            setError("");
            await fn();
            await load();
        } catch (err) {
            setError(
                err?.data?.message ??
                    err?.message ??
                    "Aksi gagal diproses.",
            );
        } finally {
            setActionLoading(false);
        }
    };

    if (loading && !surgery) {
        return (
            <DashboardLayout>
                <div className="min-h-[calc(100vh-88px)] bg-[#fafbfc] p-[30px]">
                    <div className="rounded-[14px] border border-[#ececec] bg-white p-[20px] text-[12px] text-[#999999]">
                        Memuat detail operasi...
                    </div>
                </div>
            </DashboardLayout>
        );
    }

    if (!surgery) {
        return (
            <DashboardLayout>
                <div className="min-h-[calc(100vh-88px)] bg-[#fafbfc] p-[30px]">
                    <div className="rounded-[14px] border border-red-100 bg-red-50 p-[18px] text-[12px] text-red-600">
                        {error || "Data operasi tidak ditemukan."}
                    </div>
                </div>
            </DashboardLayout>
        );
    }

    const tabs = [
        ["ringkasan", "Ringkasan"],
        ["checklist", "Checklist"],
        ["pemakaian", "Pemakaian"],
        ["pemulihan", "Pemulihan"],
        ["riwayat", "Riwayat"],
    ];

    return (
        <DashboardLayout>
            <div className="min-h-[calc(100vh-88px)] bg-[#fafbfc] p-[30px]">
                <div className="flex flex-wrap items-start justify-between gap-[16px]">
                    <div>
                        <Link
                            to="/clinical/operating-room/surgeries"
                            className="text-[11px] font-medium text-[#1688f8]"
                        >
                            ← Kembali ke Daftar Operasi
                        </Link>

                        <p className="mt-[12px] text-[11px] font-semibold text-[#1688f8]">
                            {surgery.surgery_number || "-"}
                        </p>

                        <h1 className="mt-[3px] text-[24px] font-semibold text-[#343434]">
                            {surgery.patient?.name || "Pasien"}
                        </h1>

                        <div className="mt-[9px] flex flex-wrap items-center gap-[7px]">
                            <SurgeryStatusBadge status={surgery.status} />
                            <span className="rounded-full bg-[#f3f4f6] px-[9px] py-[4px] text-[10px] font-medium text-[#666666]">
                                {priorityLabel[surgery.priority] ||
                                    surgery.priority ||
                                    "-"}
                            </span>
                        </div>
                    </div>

                    <div className="flex flex-wrap gap-[8px]">
                        {actions.map(([label, fn]) => (
                            <button
                                key={label}
                                type="button"
                                disabled={actionLoading}
                                onClick={() => runAction(fn)}
                                className="inline-flex h-[40px] items-center rounded-[9px] bg-[#1688f8] px-[15px] text-[11px] font-medium text-white transition hover:bg-[#0f7be8] disabled:cursor-not-allowed disabled:opacity-50"
                            >
                                {actionLoading ? "Memproses..." : label}
                            </button>
                        ))}
                    </div>
                </div>

                {error && (
                    <div className="mt-[16px] rounded-[10px] border border-red-100 bg-red-50 px-[14px] py-[11px] text-[12px] text-red-600">
                        {error}
                    </div>
                )}

                <div className="mt-[22px] flex gap-[6px] overflow-x-auto border-b border-[#e8e8e8] pb-[10px]">
                    {tabs.map(([value, label]) => (
                        <button
                            key={value}
                            type="button"
                            onClick={() => setTab(value)}
                            className={`whitespace-nowrap rounded-[8px] px-[13px] py-[8px] text-[11px] font-medium transition ${
                                tab === value
                                    ? "bg-[#eaf4ff] text-[#1688f8]"
                                    : "text-[#777777] hover:bg-white hover:text-[#1688f8]"
                            }`}
                        >
                            {label}
                        </button>
                    ))}
                </div>

                {tab === "ringkasan" && (
                    <div className="mt-[18px] grid grid-cols-1 gap-[14px] lg:grid-cols-2">
                        <Info
                            title="Diagnosis Pra Operasi"
                            value={surgery.preoperative_diagnosis}
                        />
                        <Info
                            title="Rencana Tindakan"
                            value={surgery.planned_procedure}
                        />
                        <Info
                            title="Jenis Operasi"
                            value={surgery.operation_type?.name}
                        />
                        <Info
                            title="Kamar Operasi"
                            value={surgery.operating_room?.name}
                        />
                        <Info
                            title="Jadwal Mulai"
                            value={dateTime(surgery.scheduled_start_at)}
                        />
                        <Info
                            title="Jadwal Selesai"
                            value={dateTime(surgery.scheduled_end_at)}
                        />
                        <Info
                            title="Dokter Operator"
                            value={doctorName(surgery.operator_doctor)}
                        />
                        <Info
                            title="Dokter Anestesi"
                            value={doctorName(surgery.anesthesiologist_doctor)}
                        />
                        <Info
                            title="Diagnosis Pasca Operasi"
                            value={surgery.postoperative_diagnosis}
                        />
                        <Info
                            title="Tindakan Operasi"
                            value={surgery.performed_procedure}
                        />
                        <Info
                            title="Komplikasi"
                            value={surgery.complications || "Tidak tercatat"}
                        />
                        <Info
                            title="Perdarahan"
                            value={
                                surgery.blood_loss_ml != null
                                    ? `${surgery.blood_loss_ml} ml`
                                    : "-"
                            }
                        />
                        <Info
                            title="Catatan Operasi"
                            value={surgery.operation_notes}
                            wide
                        />
                        <Info
                            title="Instruksi Pasca Operasi"
                            value={surgery.postoperative_instructions}
                            wide
                        />
                    </div>
                )}

                {tab === "checklist" && (
                    <div className="mt-[18px] grid grid-cols-1 gap-[16px] xl:grid-cols-2">
                        <ChecklistBlock title="Pra Operasi">
                            <SafetyChecklistPanel
                                phase="preoperative"
                                initialItems={checklist.preoperative_checklist}
                                onSave={async (items) => {
                                    await operatingRoomService.saveChecklist(
                                        id,
                                        "preoperative",
                                        { items },
                                    );
                                    await load();
                                }}
                            />
                        </ChecklistBlock>

                        <ChecklistBlock title="Sign In">
                            <SafetyChecklistPanel
                                phase="sign-in"
                                initialItems={checklist.sign_in}
                                onSave={async (items) => {
                                    await operatingRoomService.saveChecklist(
                                        id,
                                        "sign-in",
                                        { items },
                                    );
                                    await load();
                                }}
                            />
                        </ChecklistBlock>

                        <ChecklistBlock title="Time Out">
                            <SafetyChecklistPanel
                                phase="time-out"
                                initialItems={checklist.time_out}
                                onSave={async (items) => {
                                    await operatingRoomService.saveChecklist(
                                        id,
                                        "time-out",
                                        { items },
                                    );
                                    await load();
                                }}
                            />
                        </ChecklistBlock>

                        <ChecklistBlock title="Sign Out">
                            <SafetyChecklistPanel
                                phase="sign-out"
                                initialItems={checklist.sign_out}
                                onSave={async (items) => {
                                    await operatingRoomService.saveChecklist(
                                        id,
                                        "sign-out",
                                        { items },
                                    );
                                    await load();
                                }}
                            />
                        </ChecklistBlock>
                    </div>
                )}

                {tab === "pemakaian" && (
                    <div className="mt-[18px] space-y-[16px]">
                        <UsageForm
                            onSubmit={async (payload) => {
                                await operatingRoomService.addUsage(id, payload);
                                await load();
                            }}
                        />

                        <div className="rounded-[14px] border border-[#ececec] bg-white p-[18px]">
                            <h2 className="text-[15px] font-semibold text-[#343434]">
                                Riwayat Pemakaian
                            </h2>

                            <div className="mt-[12px] space-y-[8px]">
                                {surgery.usages?.length ? (
                                    surgery.usages.map((item) => (
                                        <div
                                            key={item.id}
                                            className="flex items-center justify-between gap-[12px] rounded-[9px] border border-[#eeeeee] px-[12px] py-[10px]"
                                        >
                                            <div>
                                                <p className="text-[12px] font-medium text-[#444444]">
                                                    {item.item_name}
                                                </p>
                                                <p className="mt-[2px] text-[10px] text-[#999999]">
                                                    {item.usage_type}
                                                </p>
                                            </div>
                                            <p className="text-[11px] font-semibold text-[#555555]">
                                                {item.quantity} {item.unit}
                                            </p>
                                        </div>
                                    ))
                                ) : (
                                    <p className="py-[14px] text-[11px] text-[#aaaaaa]">
                                        Belum ada pemakaian obat, bahan medis, atau alat.
                                    </p>
                                )}
                            </div>
                        </div>
                    </div>
                )}

                {tab === "pemulihan" && (
                    <div className="mt-[18px]">
                        <RecoveryForm surgery={surgery} reload={load} />
                    </div>
                )}

                {tab === "riwayat" && (
                    <div className="mt-[18px] space-y-[8px]">
                        {surgery.histories?.length ? (
                            surgery.histories.map((item) => (
                                <div
                                    key={item.id}
                                    className="rounded-[12px] border border-[#ececec] bg-white px-[14px] py-[12px]"
                                >
                                    <p className="text-[12px] font-semibold text-[#444444]">
                                        {item.event}
                                    </p>
                                    <p className="mt-[3px] text-[10px] text-[#999999]">
                                        {dateTime(item.created_at)} ·{" "}
                                        {item.active_role || "role tidak tercatat"}
                                    </p>
                                </div>
                            ))
                        ) : (
                            <div className="rounded-[12px] border border-[#ececec] bg-white p-[18px] text-[11px] text-[#aaaaaa]">
                                Belum ada riwayat operasi.
                            </div>
                        )}
                    </div>
                )}
            </div>
        </DashboardLayout>
    );
}

function Info({ title, value, wide = false }) {
    return (
        <div
            className={`rounded-[14px] border border-[#ececec] bg-white p-[18px] ${
                wide ? "lg:col-span-2" : ""
            }`}
        >
            <p className="text-[11px] font-medium text-[#999999]">{title}</p>
            <p className="mt-[5px] whitespace-pre-wrap text-[13px] font-medium leading-[1.6] text-[#444444]">
                {value || "-"}
            </p>
        </div>
    );
}

function ChecklistBlock({ title, children }) {
    return (
        <div>
            <h2 className="mb-[8px] text-[13px] font-semibold text-[#444444]">
                {title}
            </h2>
            {children}
        </div>
    );
}

function RecoveryForm({ surgery, reload }) {
    const current = surgery.recovery || {};

    const [form, setForm] = useState({
        consciousness: current.consciousness || "",
        pain_score: current.pain_score ?? "",
        nausea_vomiting: Boolean(current.nausea_vomiting),
        aldrete_score: current.aldrete_score ?? "",
        status: current.status || "observing",
        notes: current.notes || "",
    });

    const [saving, setSaving] = useState(false);

    const submit = async (event) => {
        event.preventDefault();

        try {
            setSaving(true);

            await operatingRoomService.saveRecovery(surgery.id, {
                ...form,
                pain_score:
                    form.pain_score === "" ? null : Number(form.pain_score),
                aldrete_score:
                    form.aldrete_score === ""
                        ? null
                        : Number(form.aldrete_score),
            });

            await reload();
        } finally {
            setSaving(false);
        }
    };

    return (
        <form
            onSubmit={submit}
            className="grid grid-cols-1 gap-[14px] rounded-[14px] border border-[#ececec] bg-white p-[18px] md:grid-cols-2"
        >
            <Field label="Kesadaran">
                <input
                    value={form.consciousness}
                    onChange={(e) =>
                        setForm((prev) => ({
                            ...prev,
                            consciousness: e.target.value,
                        }))
                    }
                    className={inputClass}
                />
            </Field>

            <Field label="Skor Nyeri (0-10)">
                <input
                    type="number"
                    min="0"
                    max="10"
                    value={form.pain_score}
                    onChange={(e) =>
                        setForm((prev) => ({
                            ...prev,
                            pain_score: e.target.value,
                        }))
                    }
                    className={inputClass}
                />
            </Field>

            <Field label="Aldrete Score">
                <input
                    type="number"
                    min="0"
                    max="10"
                    value={form.aldrete_score}
                    onChange={(e) =>
                        setForm((prev) => ({
                            ...prev,
                            aldrete_score: e.target.value,
                        }))
                    }
                    className={inputClass}
                />
            </Field>

            <Field label="Status Pemulihan">
                <select
                    value={form.status}
                    onChange={(e) =>
                        setForm((prev) => ({
                            ...prev,
                            status: e.target.value,
                        }))
                    }
                    className={inputClass}
                >
                    <option value="waiting">Menunggu</option>
                    <option value="observing">Observasi</option>
                    <option value="ready_transfer">Siap Transfer</option>
                    <option value="transferred">Sudah Transfer</option>
                    <option value="escalated">Eskalasi</option>
                </select>
            </Field>

            <label className="flex items-center gap-[9px] rounded-[9px] border border-[#eeeeee] px-[12px] py-[10px]">
                <input
                    type="checkbox"
                    checked={form.nausea_vomiting}
                    onChange={(e) =>
                        setForm((prev) => ({
                            ...prev,
                            nausea_vomiting: e.target.checked,
                        }))
                    }
                    className="h-[16px] w-[16px] accent-[#1688f8]"
                />
                <span className="text-[12px] text-[#555555]">Mual / Muntah</span>
            </label>

            <div className="md:col-span-2">
                <Field label="Catatan Pemulihan">
                    <textarea
                        value={form.notes}
                        onChange={(e) =>
                            setForm((prev) => ({
                                ...prev,
                                notes: e.target.value,
                            }))
                        }
                        rows="4"
                        className="w-full resize-y rounded-[9px] border border-[#dddddd] bg-white px-[12px] py-[10px] text-[13px] text-[#444444] outline-none transition focus:border-[#1688f8]"
                    />
                </Field>
            </div>

            <button
                type="submit"
                disabled={saving}
                className="inline-flex h-[42px] items-center justify-center rounded-[9px] bg-[#1688f8] px-[17px] text-[12px] font-medium text-white transition hover:bg-[#0f7be8] disabled:cursor-not-allowed disabled:opacity-50 md:col-span-2"
            >
                {saving ? "Menyimpan..." : "Simpan Pemulihan"}
            </button>
        </form>
    );
}

const inputClass = `
    h-[42px]
    w-full
    rounded-[9px]
    border
    border-[#dddddd]
    bg-white
    px-[12px]
    text-[13px]
    text-[#444444]
    outline-none
    transition
    focus:border-[#1688f8]
`;

function Field({ label, children }) {
    return (
        <div>
            <label className="mb-[6px] block text-[12px] font-medium text-[#555555]">
                {label}
            </label>
            {children}
        </div>
    );
}

function doctorName(doctor) {
    return doctor?.employee?.name ?? doctor?.name ?? "-";
}
