<?php

namespace App\Enums;

enum SurgeryStatus: string
{
    case REQUESTED = 'requested';
    case SCHEDULED = 'scheduled';
    case PREOP = 'preop';
    case READY = 'ready';
    case IN_PROGRESS = 'in_progress';
    case RECOVERY = 'recovery';
    case COMPLETED = 'completed';
    case CANCELLED = 'cancelled';

    public function label(): string
    {
        return match ($this) {
            self::REQUESTED => 'Permintaan',
            self::SCHEDULED => 'Terjadwal',
            self::PREOP => 'Pra Operasi',
            self::READY => 'Siap Operasi',
            self::IN_PROGRESS => 'Sedang Operasi',
            self::RECOVERY => 'Pemulihan',
            self::COMPLETED => 'Selesai',
            self::CANCELLED => 'Dibatalkan',
        };
    }
}
