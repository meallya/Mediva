import React, { useState } from "react";

const initial = {
    usage_type: "medicine",
    item_name: "",
    quantity: 1,
    unit: "",
    unit_price: 0,
    billable: true,
    medicine_id: "",
    inventory_item_id: "",
    asset_id: "",
    notes: "",
};

export default function UsageForm({ onSubmit }) {
    const [form, setForm] = useState(initial);
    const [saving, setSaving] = useState(false);

    const change = (event) => {
        const { name, value, type, checked } = event.target;

        setForm((prev) => ({
            ...prev,
            [name]: type === "checkbox" ? checked : value,
        }));
    };

    const submit = async (event) => {
        event.preventDefault();
        setSaving(true);

        try {
            await onSubmit({
                ...form,
                quantity: Number(form.quantity),
                unit_price: Number(form.unit_price || 0),
                medicine_id:
                    form.usage_type === "medicine" && form.medicine_id
                        ? Number(form.medicine_id)
                        : null,
                inventory_item_id:
                    form.usage_type === "medical_material" &&
                    form.inventory_item_id
                        ? Number(form.inventory_item_id)
                        : null,
                asset_id:
                    form.usage_type === "asset" && form.asset_id
                        ? Number(form.asset_id)
                        : null,
            });

            setForm(initial);
        } finally {
            setSaving(false);
        }
    };

    return (
        <form
            onSubmit={submit}
            className="grid grid-cols-1 gap-[14px] rounded-[14px] border border-[#ececec] bg-white p-[18px] md:grid-cols-2"
        >
            <Field label="Jenis Pemakaian">
                <select
                    name="usage_type"
                    value={form.usage_type}
                    onChange={change}
                    className={inputClass}
                >
                    <option value="medicine">Obat</option>
                    <option value="medical_material">Bahan Medis</option>
                    <option value="asset">Alat / Alkes</option>
                </select>
            </Field>

            {form.usage_type === "medicine" && (
                <Field label="ID Obat">
                    <input
                        name="medicine_id"
                        type="number"
                        min="1"
                        value={form.medicine_id}
                        onChange={change}
                        required
                        className={inputClass}
                    />
                </Field>
            )}

            {form.usage_type === "medical_material" && (
                <Field label="ID Item Inventaris">
                    <input
                        name="inventory_item_id"
                        type="number"
                        min="1"
                        value={form.inventory_item_id}
                        onChange={change}
                        required
                        className={inputClass}
                    />
                </Field>
            )}

            {form.usage_type === "asset" && (
                <Field label="ID Asset / Alkes">
                    <input
                        name="asset_id"
                        type="number"
                        min="1"
                        value={form.asset_id}
                        onChange={change}
                        required
                        className={inputClass}
                    />
                </Field>
            )}

            <Field label="Nama Item">
                <input
                    name="item_name"
                    value={form.item_name}
                    onChange={change}
                    required
                    className={inputClass}
                />
            </Field>

            <Field label="Jumlah">
                <input
                    name="quantity"
                    type="number"
                    step="0.001"
                    min="0.001"
                    value={form.quantity}
                    onChange={change}
                    required
                    className={inputClass}
                />
            </Field>

            <Field label="Satuan">
                <input
                    name="unit"
                    value={form.unit}
                    onChange={change}
                    className={inputClass}
                />
            </Field>

            <Field label="Harga Satuan">
                <input
                    name="unit_price"
                    type="number"
                    min="0"
                    value={form.unit_price}
                    onChange={change}
                    className={inputClass}
                />
            </Field>

            <label className="flex items-center gap-[9px] rounded-[9px] border border-[#eeeeee] px-[12px] py-[10px]">
                <input
                    name="billable"
                    type="checkbox"
                    checked={form.billable}
                    onChange={change}
                    className="h-[16px] w-[16px] accent-[#1688f8]"
                />
                <span className="text-[12px] text-[#555555]">
                    Masuk tagihan pasien
                </span>
            </label>

            <div className="md:col-span-2">
                <Field label="Catatan">
                    <textarea
                        name="notes"
                        value={form.notes}
                        onChange={change}
                        rows="4"
                        className="w-full resize-y rounded-[9px] border border-[#dddddd] bg-white px-[12px] py-[10px] text-[13px] text-[#444444] outline-none transition focus:border-[#1688f8]"
                    />
                </Field>
            </div>

            <button
                type="submit"
                disabled={saving}
                className="inline-flex h-[42px] items-center justify-center rounded-[9px] bg-[#1688f8] px-[17px] text-[12px] font-medium text-white transition hover:bg-[#0f7be8] disabled:cursor-not-allowed disabled:opacity-50 md:col-span-2"
            >
                {saving ? "Menyimpan..." : "Catat Pemakaian"}
            </button>
        </form>
    );
}

const inputClass = `
    h-[42px]
    w-full
    rounded-[9px]
    border
    border-[#dddddd]
    bg-white
    px-[12px]
    text-[13px]
    text-[#444444]
    outline-none
    transition
    focus:border-[#1688f8]
`;

function Field({ label, children }) {
    return (
        <div>
            <label className="mb-[6px] block text-[12px] font-medium text-[#555555]">
                {label}
            </label>
            {children}
        </div>
    );
}
